#include <stdio.h>

void message(char* str)
{
	fprintf(stderr, str);
}
