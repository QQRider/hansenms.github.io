function y = fft2(x)
% needed for freemat 4.0
y = fftn(x);
