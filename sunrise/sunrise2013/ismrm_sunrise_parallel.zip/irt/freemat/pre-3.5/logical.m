function y = logical(x)
y = x ~= 0;
